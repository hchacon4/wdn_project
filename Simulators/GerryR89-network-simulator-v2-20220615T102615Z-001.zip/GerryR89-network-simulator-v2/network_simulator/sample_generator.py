import numpy as np
import multiprocessing as mp
import pandas as pd
import json

from pathlib import Path
from .water_network_simulator import WaterNetworkSimulator

rng = None

def _save_results(sample_folder, data, file_format, debug):
    for key in data:
        if debug or key in ['node_head', 'node_demand', 'leak_head', 'leak_demand']:
            if file_format == 'hdf':
                data[key].to_hdf(sample_folder / 'data.h5', key=key)
            elif file_format == 'csv':
                data[key].to_csv(sample_folder / f'{key}.csv')
            else:
                print(f'Format {file_format} not valid')


def _build_sample(main_folder, inp_file, cid, num_leaks, leak_area, valid_pipes, uniform, file_format, debug, seeds):
    # Use a global random generator in each process
    global rng
    if rng is None:
        current = mp.current_process()
        p_id = current._identity[0] - 1
        rng = np.random.default_rng((seeds[p_id]))
        print(f'Init rng in process {p_id}')

    # Create sample folder
    assert(cid < 1e7)
    sample_folder = main_folder / f'{cid:06}'
    sample_folder.mkdir(exist_ok=True)

    # Init water network model
    wn_sim = WaterNetworkSimulator(inp_file)

    # Choose random pipes
    if isinstance(num_leaks, int):
        n = num_leaks
    else:
        n = num_leaks(rng)

    leak_pipes = wn_sim.random_pipes(n, rng, valid_pipes, uniform)

    # Choose random leak size
    if isinstance(leak_area, float):
        leak_areas = [leak_area]*n
    else:
        leak_areas = leak_area(n, rng)

    # Run simulation
    data = wn_sim.run(leak_pipes, leak_areas, file_prefix=str(sample_folder / 'sim'))

    # Save results
    _save_results(sample_folder, data, file_format, debug)

    # Save info
    info = {
        'leak_pipes': list(leak_pipes),
        'leak_areas': list(leak_areas)
    }

    with open(sample_folder / 'info.json', 'w') as f:
        json.dump(info, f)


def _build_base_sample(main_folder, inp_file, file_format, debug):
    # Create sample folder
    sample_folder = main_folder / '_base_'
    sample_folder.mkdir(exist_ok=True)

    # Init water network model
    wn_sim = WaterNetworkSimulator(inp_file)

    # Run simulation
    data = wn_sim.run_without_leak(file_prefix=str(sample_folder / 'sim'))

    # Save results
    _save_results(sample_folder, data, file_format, debug)

    # Save info
    info = {
        'nodes': {
            'tanks': wn_sim.wn.tank_name_list,
            'reservoirs': wn_sim.wn.reservoir_name_list,
            'junctions': wn_sim.wn.junction_name_list
        },
        'links': {
            'pipes': wn_sim.wn.pipe_name_list,
            'pumps': wn_sim.wn.pump_name_list,
            'valves': wn_sim.wn.valve_name_list
        }
    }

    with open(sample_folder / 'info.json', 'w') as f:
        json.dump(info, f)


def sample_generator(output_folder, inp_file, n_samples, num_leaks, leak_area, valid_pipes=None, uniform=False, file_format='csv', debug=False, n_jobs=1, seed=None):
    assert(file_format in ['csv', 'hdf'])

    main_folder = Path(output_folder)
    main_folder.mkdir(exist_ok=True)

    # Create base case without leaks
    _build_base_sample(main_folder, inp_file, file_format, debug)

    if n_jobs < 0:
        n_jobs = mp.cpu_count()
    else:
        assert(0 < n_jobs <= mp.cpu_count())
        
    print('CPU used:', n_jobs)
    with mp.Pool(n_jobs) as pool:
        ss = np.random.SeedSequence(seed)
        seeds = ss.spawn(n_jobs)
        pool.starmap(_build_sample, [(main_folder, inp_file, cid, num_leaks, leak_area, valid_pipes, uniform, file_format, debug, seeds) for cid in range(n_samples)])
    

if __name__ == '__main__':
    inp_file = 'networks/bwcn8-168-true.inp'
    output_folder = 'temp_test'

    def leak_area(n, rng):
        return rng.uniform(low=0.01*0.01, high=0.1*0.1, size=n)

    def num_leaks(rng):
        leaks = [1, 2, 3]
        probs = [0.5, 0.3, 0.2]
        return rng.choice(leaks, size=1, replace=True, p=probs)[0]

    sample_generator(output_folder, inp_file, 16, num_leaks=num_leaks, leak_area=leak_area, file_format='hdf', debug=False, n_jobs=8, uniform=True) #valid_pipes=['P858', 'P157']
