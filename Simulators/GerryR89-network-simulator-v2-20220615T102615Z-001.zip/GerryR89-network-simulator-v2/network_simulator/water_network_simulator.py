import wntr
import matplotlib.pyplot as plt
import os
import numpy as np
import networkx as nx


class WaterNetworkSimulator:

    def __init__(self, inp_file):
        self.inp_file = inp_file
        self.wn = wntr.network.WaterNetworkModel(self.inp_file)
        self.discharge_coeff = 0.75
        self.water_density = 997
        self.leak_nodes = []
        self.distance_matrix = None

    def _get_leak_water_network(self, broken_pipes, leak_areas):
        wn_leak = self.wn
        for broken_pipe, leak_area in zip(broken_pipes, leak_areas):
            # add leak node at the center of the broken pipe
            extra_pipe = f'__{broken_pipe}'
            leak_node_name = f'__L_{broken_pipe}'
            wn_leak = wntr.morph.split_pipe(wn_leak, broken_pipe, extra_pipe, leak_node_name)
            leak_node = wn_leak.get_node(leak_node_name)
            self.leak_nodes.append(leak_node_name)

            # model leak as epanet emitter
            leak_node.emitter_coefficient = self.discharge_coeff*leak_area*(2/self.water_density)**.5

        return wn_leak

    def _parse_results(self, wn, results):
        data = {
            'node_head': results.node['head'][self.wn.node_name_list],
            'node_pressure': results.node['pressure'][self.wn.node_name_list],
            'node_demand': results.node['demand'][self.wn.node_name_list],
            'link_flowrate': results.link['flowrate'][self.wn.link_name_list],
            'link_headloss': results.link['headloss'][self.wn.link_name_list],
            'link_velocity': results.link['velocity'][self.wn.link_name_list]
        }
        if self.leak_nodes:
            data.update({
                'leak_head': results.node['head'][self.leak_nodes],
                'leak_pressure': results.node['pressure'][self.leak_nodes],
                'leak_demand': results.node['demand'][self.leak_nodes]
            })

        return data

    def _sanity_check(self, results):
        if results.node['pressure'][self.wn.junction_name_list].values.min() < 0:
            print('WARNING: negative pressures in the simulation, check input parameters')

    def _run_simulation(self, wn, file_prefix):
        sim = wntr.sim.EpanetSimulator(wn)
        results = sim.run_sim(file_prefix=file_prefix)

        self._sanity_check(results)

        return self._parse_results(wn, results)

    def random_pipes(self, n=1, rng=np.random, valid_pipes=None, uniform=False):
        pipes   = []
        weights = []
        for pipe_name, pipe in self.wn.pipes():
            if valid_pipes is None or pipe_name in valid_pipes:
                pipes.append(pipe_name)
                weights.append(pipe.length)
        weights = np.array(weights)

        probabilities = weights/weights.sum()

        if n > len(pipes):
            raise ValueError(f'Number of leaks ({n}) cannot be greater than number of valid pipes ({len(pipes)})')

        if uniform:
            return rng.choice(pipes, size=n, replace=False)
        else:
            return rng.choice(pipes, size=n, replace=False, p=probabilities)

    def run(self, broken_pipes, leak_areas, file_prefix='temp'):
        wn_leak = self._get_leak_water_network(broken_pipes, leak_areas)
        data = self._run_simulation(wn_leak, file_prefix)

        self._clean_output_folder(file_prefix)

        return data

    def run_without_leak(self, file_prefix='temp'):
        data = self._run_simulation(self.wn, file_prefix)

        self._clean_output_folder(file_prefix)

        return data

    def _clean_output_folder(self, file_prefix):
        try:
            os.remove(f'{file_prefix}.bin')
        except OSError:
            print(f'Simulation file {file_prefix}.bin not found')

    def plot(self, ax, leak_pipe, detected_pipe):
        # check if pipes exist
        assert(leak_pipe in self.wn.pipe_name_list and detected_pipe in self.wn.pipe_name_list)

        # assign values to pipes
        if leak_pipe == detected_pipe:
            link_attribute = {
                leak_pipe: 0.5
            }
        else:
            link_attribute = {
                leak_pipe: 1,
                detected_pipe: -1
            }

        # plot using wntr
        wntr.graphics.plot_network(
            self.wn, 
            ax=ax, 
            link_attribute=link_attribute, 
            node_size=30, 
            link_width=4,
            link_range=[-1, 1],
            title='Leak nodes'
        )

    def distance(self, pipe1, pipe2):
        # check if pipes are equal
        if pipe1 == pipe2:
            return 0

        # if distance matrix is not initialized, build it
        if self.distance_matrix is None:
            graph = self.wn.get_graph()
            self.distance_matrix = dict(nx.shortest_path_length(graph.to_undirected()))

        # get nodes connected to the 2 pipes
        link1 = self.wn.get_link(pipe1)
        nodes1 = [link1.start_node_name, link1.end_node_name]

        link2 = self.wn.get_link(pipe2)
        nodes2 = [link2.start_node_name, link2.end_node_name]

        # compute distances for each combination of nodes
        node_distances = []
        for n1 in nodes1:
            for n2 in nodes2:
                node_distances.append(self.distance_matrix[n1][n2])

        # return pipe distance
        return min(node_distances) + 1

        
if __name__ == '__main__':
    inp_file = 'networks/bwcn8-168-true.inp'
    wn_sim = WaterNetworkSimulator(inp_file)
    pipes = wn_sim.random_pipes(5)
    print(f'Random pipes: {pipes}')
    data = wn_sim.run(pipes, [0.05*0.05]*5)
    print(data['node_pressure']['J164'][:5])

    plt.figure()
    ax = plt.gca()
    wn_sim.plot(ax, 'P858', 'P157')
    # plt.show()

    print(f'Distance: {wn_sim.distance("P858", "P157")}')
