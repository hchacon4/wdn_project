from network_simulator import sample_generator

if __name__ == '__main__':
    inp_file = '../networks/bwcn8-168-true.inp'
    output_folder = 'temp_test'

    def leak_area(n, rng):
        return rng.uniform(low=0.01*0.01, high=0.1*0.1, size=n)

    def num_leaks(rng):
        leaks = [1, 2, 3]
        probs = [0.5, 0.3, 0.2]
        return rng.choice(leaks, size=1, replace=True, p=probs)[0]

    sample_generator(
        output_folder, 
        inp_file, 
        n_samples=10, 
        num_leaks=num_leaks, 
        leak_area=leak_area, 
        file_format='csv', 
        debug=True, 
        n_jobs=1
    )