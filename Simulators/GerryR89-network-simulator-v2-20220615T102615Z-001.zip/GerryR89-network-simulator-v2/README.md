# Sensor Placement Simulator #

Generate training data for Sensor Placement using EPANET.

## Getting started ##

1. `git clone git@bitbucket.org:GerryR89/network-simulator.git`
2. `pip install network-simulator` (or use the path to your local repo)
3. Check if the package is installed: `pip freeze | grep network-simulator`
4. Use generator: 

        from network_simulator import sample_generator

## How to use the sample generator ##

The `sample_generator` function accepts these arguments:

- `output_folder`: path to the output folder
- `inp_file`: path to the EPANET input file
- `n_samples`: number of leak scenarios 
- `num_leaks`: either an integer, or a function like:

        def num_leaks(rng):
            leaks = [1, 2, 3]
            probs = [0.5, 0.3, 0.2]
            return rng.choice(leaks, size=1, replace=True, p=probs)[0]

- `leak_area`: either a float, or a function like:
  
        def leak_area(n, rng):
            return rng.uniform(low=0.01*0.01, high=0.1*0.1, size=n)

- `valid_pipes`: a list or set of pipes where a leak can be placed, note that the number of elements must be greater or equal than the maximum number of `num_leaks`. If None, the leak can be placed in any pipe
- `uniform`: if `True`, sample leak pipes uniformly, otherwsie the leak probability is proportional to the length of the pipe
- `file_format`: either `csv` or `hdf`
- `debug`: if `True`, output more variables to the output folder
- `n_jobs`: number of parallel processes. If `-1`, then use all the available processors.


## How to develop the simulator ##

1. Prepare the virtual environment:

        python -m venv .env
        source .env/bin/activate
        pip install -r requirements.txt

2. If you use VScode, select virtual environment using `cmd+shit+P > Select interpreter`
3. Create pull requests to `develop`

## Contacts ##

* Gerry Rizzo (grizzo@beyond.ai)