import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="network-simulator",
    version="0.0.7",
    author="Calogero B. Rizzo",
    author_email="grizzo@beyond.ai",
    description="Generate training data for Sensor Placement using EPANET",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://bitbucket.org/GerryR89/network-simulator",
    packages=['network_simulator'],
    classifiers=[],
    python_requires='>=3.6',
    install_requires=[
        'wntr',
        'pandas',
        'numpy',
        'scipy',
        'matplotlib',
        'plotly'
    ]
)